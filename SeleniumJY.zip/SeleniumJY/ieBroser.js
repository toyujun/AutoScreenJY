const ie = require('selenium-webdriver/ie');
const path = require('iedriver').path;
const { Builder, By, Key, until, Options } = require('selenium-webdriver');


var webdriver = require('selenium-webdriver');
var driver = new webdriver.Builder()
    .forBrowser('internet explorer')
    .build();

    (async function example() {
        // let driver = await new Builder().forBrowser('firefox').build();
        try {
            // Navigate to Url
            await driver.get('http://www.baidu.com');
    
            await driver.findElement(By.id('kw')).sendKeys('webdriver');
            // await driver.wait(until.titleIs('webdriver_百度搜索'), 5000);
        }
        finally {
            driver.quit();
        }
    })();
