const webdriver = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const path = require('chromedriver').path;
const { Builder, By, Key, until, Options } = require('selenium-webdriver');
const fs = require('fs');


const options = new chrome.Options();
options.addArguments("--start-maximized"); // 启动就最大化，而不是像后面再使用 maximize() 那样之后再最大化
options.addArguments("--disable-popup-blocking");
options.addArguments("no-sandbox");
options.addArguments("disable-extensions");
options.addArguments("no-default-browser-check");

const service = new chrome.ServiceBuilder(path).build();
chrome.setDefaultService(service);

const driver = new webdriver.Builder()
    .setChromeOptions(options)
    .withCapabilities(webdriver.Capabilities.chrome())
    .forBrowser('chrome')
    .build();

(async function example() {
    // let driver = await new Builder().forBrowser('firefox').build();
    try {
        // Navigate to Url
        await driver.get('http://www.baidu.com');

        await driver.findElement(By.id('kw')).sendKeys('webdriver', Key.RETURN);
        await driver.wait(until.titleIs('webdriver_百度搜索'), 5000);
        // const contentEle = await driver.findElement(By.id('content_left'));

        // body height
        const height = await driver.executeScript('return document.body.clientHeight');

        // view height
        const vwHeight = await driver.executeScript('return document.documentElement.clientHeight');

        // const eleTop = await driver.executeScript(`return ${getElementTop(document.getElementById('content_left'))}`);

        console.log(height, vwHeight);
        for (let i = 0; i < Math.round(height / vwHeight); i++) {
            const move = i * (vwHeight - 70);
            console.log(move);
            driver.executeScript(`window.scrollTo(0,${move})`);
            await saveScreenShot(i);
        }
    }
    finally {
        driver.quit();
    }
})();

async function saveScreenShot(index) {
    await waitTime(300);
    let base64 = await driver.takeScreenshot();
    let b = Buffer.from(base64, 'base64');
    fs.writeFileSync(`./t${index}.png`, b);
}

function getElementTop(element) {
    var actualTop = element.offsetTop;
    var current = element.offsetParent;

    while (current !== null) {
        actualTop += current.offsetTop;
        current = current.offsetParent;
    }

    return actualTop;
}

function waitTime(n) {
    return new Promise(resolve => setTimeout(
        () => resolve()
        , n
    ))
}